import MySQLdb


class MySQLConnect:
    __conn = None
    __cur = None

    def __init__(self):
        self.__create()

    # def __del__(self):
    #     self.__cur.close()
    #     self.__conn.close()

    @classmethod
    def __create(cls):
        cls.__conn = MySQLdb.connect(host='localhost', user='root', passwd='', port=3306)
        cls.__cur = cls.__conn.cursor()
        cls.__conn.select_db('python_crawl')
        cls.__conn.set_character_set('utf8')
        cls.__cur.execute('SET NAMES utf8;')
        cls.__cur.execute('SET CHARACTER SET utf8;')
        cls.__cur.execute('SET character_set_connection=utf8;')

    @classmethod
    def insert_video(cls, v):
        try:
            cls.__cur.executemany('INSERT INTO t_video_info VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', v)
            cls.__conn.commit()
        except Exception, e:
            print e
            cls.__create()
            # self.insert_video(v)

    def insert_author(self, values):
        self.__cur.excutemany('INSERT INTO t_author_info VALUES (%s, %s, %s, %s, %s)', values)
        self.__cur.commit()

    def clear_all(self):
        self.__cur.execute('DELETE FROM t_video_info')
        self.__cur.execute('DELETE FROM t_author_info')
        self.__cur.commit()
