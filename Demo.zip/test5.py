# coding=utf-8
from test4 import Crawler
from test6 import MySQLConnect
import threading
conn = MySQLConnect()


def func(i):
    per_crawl = 50
    store_count = 10
    count = 0
    # 创建线程锁，避免IO操作报错
    mutex = threading.Lock()
    for it in range(0, per_crawl / store_count):
        st = 1000+it*store_count+i*per_crawl
        ed = 1000+(it+1)*store_count+i*per_crawl
        worker[i].run(st, ed)
        p = worker[i].output('video')
        for pp in p:
            print pp

        # 锁定
        if mutex.acquire(1):
            conn.insert_video(p)
            # 释放
            mutex.release()
        it += 1
        count += len(p)

worker = []
result = []
threads = []
for k in range(0, 10):
    worker.append(Crawler())
    threads.append(threading.Thread(target=func, args=(k,)))

if __name__ == '__main__':
    t = None
    for t in threads:
        # t.setDaemon(True)
        t.start()

    t.join()

exit(0)
